<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Magazine extends Model
{
    protected $table='magazines';
    protected $fillable=['title','file','journalist_id'];
    public function jornalist(){
        $this->belongsTo(Journalist::class,'journalist_id','id');
    }


    public function adds(){
        $this->hasMany(Adds::class,'magazine_id','id');
    }
}
